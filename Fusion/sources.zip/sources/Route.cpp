
#include "Route.h"

void Route::set(long long p_id, long long p_nb_stops, long long p_nb_trips){
  id = p_id;
  nb_stops = p_nb_stops;
  nb_trips = p_nb_trips;
}
