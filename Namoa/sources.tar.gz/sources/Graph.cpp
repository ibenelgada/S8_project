
#include "Graph.h"



std::ostream& operator<<(std::ostream& os, const Graph& Graph){
    os << "not defined" << std::endl;
    return os;
}
