
#include "Node.h"


Node::Node():id(-1){};


std::ostream& operator<<(std::ostream& os, const Node& node){
    os << "not defined" << std::endl;
    return os;
}
